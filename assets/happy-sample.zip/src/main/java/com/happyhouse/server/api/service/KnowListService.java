package com.happyhouse.server.api.service;

import com.happyhouse.server.api.domain.KnowList;
import com.happyhouse.server.api.repository.KnowListRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional
@Slf4j
public class KnowListService {

    private final KnowListRepository knowListRepository;

    public List<KnowList> getAllList() {
        return knowListRepository.getAllList();
    }

//    public User findById(Integer id) {
//
//        return  userRepository.findById(id);
//    }
//
//    public User findByEmail(String email) {
//
//        Map<String, Object> sqlParams = new HashMap<>();
//        sqlParams.put("email", email);
//
//        return userRepository.findByEmail(sqlParams);
//    }
//
//    public void create(User user) {
//
//        userRepository.create(user);
//    }
//
//    public void update(User user) {
//
//        userRepository.update(user);
//    }
//
//    public void delete(Integer id) {
//
//        userRepository.delete(id);
//    }
}
