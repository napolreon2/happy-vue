package com.happyhouse.server.api.controller;

import com.happyhouse.server.api.controller.dto.KnowListDTO;
import com.happyhouse.server.api.controller.mapper.KnowListMapper;
import com.happyhouse.server.api.domain.KnowList;
import com.happyhouse.server.api.service.IGPService;
import com.happyhouse.server.api.service.KnowListService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.mapstruct.factory.Mappers;
import org.springframework.context.MessageSource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

/*
    http(s)://project.example.com/api/v1/common/management/codes/{codeId}
                                          Part   Module   Resource
    [method]
    query : Collection(GET)
    get   : Object(GET)
    create : (POST)
    update : (PUT)
    modify : (PATCH)
    delete : (DELETE)

*/

@Api("지식목록")
@RestController
@RequiredArgsConstructor
@RequestMapping(path = "/api/v1/happy/knowList", produces = MediaType.APPLICATION_JSON_VALUE)
@Slf4j
public class KnowListResource {

    private final KnowListMapper knowListMapper = Mappers.getMapper(KnowListMapper.class);
    private final KnowListService knowListService;
    private final IGPService igpService;
    private final MessageSource messageSource;

    @ApiOperation("지식목록 전체조회")
    @GetMapping
    public ResponseEntity<List<KnowListDTO>> query() {
        List<KnowList> kList = knowListService.getAllList();

        List<KnowListDTO> returnList = new ArrayList<KnowListDTO>();
        for(KnowList k: kList){
            KnowListDTO dto = knowListMapper.toDTO(k);
            returnList.add(dto);
        }

        return ResponseEntity.ok(returnList);

//        User user = userService.findById();
//        UserDTO userDTO = userMapper.toDTO(user);
//        return ResponseEntity.ok(userDTO);
    }

//    @ApiOperation("등록")
//    @PostMapping
//    @ResponseStatus(HttpStatus.CREATED)
//    public ResponseEntity<UserDTO> create(@RequestBody @ApiParam("사용자") User user) {
//        userService.create(user);
//        URI uri = WebMvcLinkBuilder.linkTo(KnowListResource.class).slash(user.getId()).toUri();
//        UserDTO userDTO = userMapper.toDTO(user);
//
//        /*
//            modelMapper.typeMap(Order.class, OrderDTO.class).addMappings(mapper -> {
//                mapper.map(src -> src.getBillingAddress().getStreet(),
//                        Destination::setBillingStreet);
//                mapper.map(src -> src.getBillingAddress().getCity(),
//                        Destination::setBillingCity);
//            });
//         */
//
//        return ResponseEntity.created(uri).body(userDTO);
//    }

//    @ApiOperation("수정")
//    @PutMapping
//    @ResponseStatus(HttpStatus.OK)
//    public ResponseEntity<UserDTO> update(@RequestBody @ApiParam("사용자") User user) {
//
//        userService.update(user);
//        UserDTO userDTO = userMapper.toDTO(user);
//        return ResponseEntity.ok(userDTO);
//    }

//    @ApiOperation("삭제")
//    @DeleteMapping("/{id}")
//    @ResponseStatus(HttpStatus.NO_CONTENT)
//    public void delete(@PathVariable @ApiParam("사용자") Integer id) {
//
//        userService.delete(id);
//    }

//    @ApiOperation("단건조회 by id")
//    @GetMapping("/{id}")
//    public ResponseEntity<UserDTO> getById(@PathVariable @ApiParam("ID") Integer id) {
//
//        User user = userService.findById(id);
//        UserDTO userDTO = userMapper.toDTO(user);
//        return ResponseEntity.ok(userDTO);
//    }

//    @ApiOperation("단건조회 by 이메일")
//    @GetMapping
//    public ResponseEntity<UserDTO> getByEmail(@RequestParam @ApiParam("이메일") String email) {
//        User user = userService.findByEmail(email);
//
//        String message = messageSource.getMessage("alert.save", new Object[]{"신관영", 1}, LocaleContextHolder.getLocale());
//        log.info("{}", message);
//        message = messageSource.getMessage("alert.saved", null, LocaleContextHolder.getLocale());
//        log.info("{}", message);
//        message = messageSource.getMessage("alert.save", new Object[]{"Shin Kwan Young", 1}, Locale.US);
//        log.info("{}", message);
//        message = messageSource.getMessage("alert.saved", null, Locale.US);
//        log.info("{}", message);
//
//        UserDTO userDTO = userMapper.toDTO(user);
//
//        return ResponseEntity.ok(userDTO);
//    }

//    @GetMapping("/igp")
//    public ResponseEntity<UserDTO> getByEmailFromIgp(@RequestParam @ApiParam("이메일") String email) {
//        UserDTO userDto = igpService.findByEmail(email);
//        return ResponseEntity.ok(userDto);
//    }

}

