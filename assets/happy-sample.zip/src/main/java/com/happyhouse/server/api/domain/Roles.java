package com.happyhouse.server.api.domain;

public enum Roles {
    ROLE_USER, ROLE_ADMIN, ROLE_MANAGER
}