package com.happyhouse.server.api.domain;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.sql.Timestamp;

@Getter
@Setter
@NoArgsConstructor
public class KnowList {
    /**
     * 지식id
     */
//    private Integer knowId;
    private Integer KNOW_ID;
    /**
     * 최종변경자id
     */
    private String LAST_CHNGR_ID;

    /**
     * 최종변경일시
     */
    private Timestamp LAST_CHNG_DTMD;

    /**
     * 최초등록자id
     */
    private String FST_REGR_ID;

    /**
     * 최초등록일시
     */
    private Timestamp FST_REG_DTMD;

    /**
     * 지식제목명
     */
    private String KNOW_TITLE_NM;

    /**
     * 메인노출여부
     */
    private String MAIN_EXPSE_YN;

    /**
     * 모바일 사용여부
     */
    private String MOBL_USE_YN;

    /**
     * 게시시작일자
     */
    private String BLTN_START_DT;

    /**
     * 게시종료일자
     */
    private String BLTN_END_DT;

    /**
     * 지식상태코드
     */
    private String KNOW_STS_CD;

    /**
     * 지식상태변경일시
     */
    private Timestamp KNOW_STS_CHNG_DTMD;

    /**
     * 지식등록사용자id
     */
    private String KNOW_REG_USERID;

    /**
     * 조회건수
     */
    private Integer BRWS_CCNT;

    /**
     * 지식태그내용
     */
    private String KNOW_TAG_CNTNT;

    /**
     * 지식내용
     */
    private String KNOW_CNTNT;
}