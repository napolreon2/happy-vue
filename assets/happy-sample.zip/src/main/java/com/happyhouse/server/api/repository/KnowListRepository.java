package com.happyhouse.server.api.repository;

import com.happyhouse.server.api.domain.KnowList;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface KnowListRepository {

    /*
        findByLastnameAndFirstname
        findByLastnameOrFirstname
        findByFirstname,findByFirstnameIs,findByFirstnameEquals
        findByStartDateBetween
        findByAgeLessThan
        findByAgeLessThanEqual
        findByAgeGreaterThan
        findByAgeGreaterThanEqual
        findByStartDateAfter
        findByStartDateBefore
        findByAgeIsNull
        findByAge(Is)NotNull
        findByFirstnameLike
        findByFirstnameNotLike
        findByFirstnameStartingWith
        findByFirstnameEndingWith
        findByFirstnameContaining
        findByAgeOrderByLastnameDesc
        findByLastnameNot
        findByAgeIn(Collection<Age> ages)
        findByAgeNotIn(Collection<Age> age)
        findByActiveTrue()
        findByActiveFalse()
        findByFirstnameIgnoreCase
    */

    List<KnowList> getAllList();

}