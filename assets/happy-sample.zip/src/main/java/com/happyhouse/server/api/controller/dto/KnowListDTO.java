package com.happyhouse.server.api.controller.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.sql.Timestamp;


@Getter
@Setter
@NoArgsConstructor
@ApiModel(value="KmsListDTO", description = "지식목록")
public class KnowListDTO {

    @ApiModelProperty(value="지식id", required=true)
    private Integer knowId;

    @ApiModelProperty(value="최종변경자Id", required=false)
    private String lastChngrId;

    @ApiModelProperty(value="최종변경일시", required=false)
    private Timestamp lastChngDtmd;

    @ApiModelProperty(value="최초등록자ID", required=false)
    private String fstRegrId;

    @ApiModelProperty(value="최초등록일시", required=false)
    private Timestamp fstRegDtmd;

    @ApiModelProperty(value="지식제목명", required=true)
    private String knowTitleNm;

    @ApiModelProperty(value="메인노출여부", required=false)
    private String mainExpseYn;

    @ApiModelProperty(value="모바일사용여부", required=false)
    private String moblUseYn;

    @ApiModelProperty(value="게시시작일자", required=true)
    private String bltnStartDt;

    @ApiModelProperty(value="게시종료일자", required=true)
    private String bltnEndDt;

    @ApiModelProperty(value="지식상태코드", required=false)
    private String knowStsCd;

    @ApiModelProperty(value="지식상태변경일시", required=true)
    private Timestamp knowStsChngDtmd;

    @ApiModelProperty(value="지식등록사용자ID", required=true)
    private String knowRegUserid;

    @ApiModelProperty(value="조회건수", required=false)
    private Integer brwsCcnt;

    @ApiModelProperty(value="지식태그내용", required=true)
    private String knowTagCntnt;

    @ApiModelProperty(value="지식내용", required=true)
    private String knowCntnt;

}