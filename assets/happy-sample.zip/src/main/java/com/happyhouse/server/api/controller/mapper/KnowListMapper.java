package com.happyhouse.server.api.controller.mapper;

import com.happyhouse.server.api.controller.dto.KnowListDTO;
import com.happyhouse.server.api.domain.KnowList;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

@Mapper(componentModel ="spring")
public interface KnowListMapper extends GenericMapper<KnowListDTO, KnowList> {

    @Mappings({
            @Mapping(target="knowId", source="knowList.KNOW_ID"),
            @Mapping(target="lastChngrId", source="knowList.LAST_CHNGR_ID"),
            @Mapping(target="lastChngDtmd", source="knowList.LAST_CHNG_DTMD"),
            @Mapping(target="fstRegrId", source="knowList.FST_REGR_ID"),
            @Mapping(target="fstRegDtmd", source="knowList.FST_REG_DTMD"),
            @Mapping(target="knowTitleNm", source="knowList.KNOW_TITLE_NM"),
            @Mapping(target="mainExpseYn", source="knowList.MAIN_EXPSE_YN"),
            @Mapping(target="moblUseYn", source="knowList.MOBL_USE_YN"),
            @Mapping(target="bltnStartDt", source="knowList.BLTN_START_DT"),
            @Mapping(target="bltnEndDt", source="knowList.BLTN_END_DT"),
            @Mapping(target="knowStsCd", source="knowList.KNOW_STS_CD"),
            @Mapping(target="knowStsChngDtmd", source="knowList.KNOW_STS_CHNG_DTMD"),
            @Mapping(target="knowRegUserid", source="knowList.KNOW_REG_USERID"),
            @Mapping(target="brwsCcnt", source="knowList.BRWS_CCNT"),
            @Mapping(target="knowTagCntnt", source="knowList.KNOW_TAG_CNTNT"),
            @Mapping(target="knowCntnt", source="knowList.KNOW_CNTNT"),


    })
    KnowListDTO toDTO(KnowList knowList);

    @Mappings({
            @Mapping(target="KNOW_ID", source="dto.knowId"),
            @Mapping(target="LAST_CHNGR_ID", source="dto.lastChngrId"),
            @Mapping(target="LAST_CHNG_DTMD", source="dto.lastChngDtmd"),
            @Mapping(target="FST_REGR_ID", source="dto.fstRegrId"),
            @Mapping(target="FST_REG_DTMD", source="dto.fstRegDtmd"),
            @Mapping(target="KNOW_TITLE_NM", source="dto.knowTitleNm"),
            @Mapping(target="MAIN_EXPSE_YN", source="dto.mainExpseYn"),
            @Mapping(target="MOBL_USE_YN", source="dto.moblUseYn"),
            @Mapping(target="BLTN_START_DT", source="dto.bltnStartDt"),
            @Mapping(target="BLTN_END_DT", source="dto.bltnEndDt"),
            @Mapping(target="KNOW_STS_CD", source="dto.knowStsCd"),
            @Mapping(target="KNOW_STS_CHNG_DTMD", source="dto.knowStsChngDtmd"),
            @Mapping(target="KNOW_REG_USERID", source="dto.knowRegUserid"),
            @Mapping(target="BRWS_CCNT", source="dto.brwsCcnt"),
            @Mapping(target="KNOW_TAG_CNTNT", source="dto.knowTagCntnt"),
            @Mapping(target="KNOW_CNTNT", source="dto.knowCntnt"),
    })
    KnowList toDomain(KnowListDTO dto);

}
